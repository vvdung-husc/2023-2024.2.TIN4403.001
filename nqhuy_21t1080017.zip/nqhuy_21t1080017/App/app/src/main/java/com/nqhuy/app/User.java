package com.nqhuy.app;

public class User {
    public static String _username;
    public static String _fullname = "<rỗng>";
    public static String _email = "<chưa có>";
    public static String _password = "<rỗng>";

}
